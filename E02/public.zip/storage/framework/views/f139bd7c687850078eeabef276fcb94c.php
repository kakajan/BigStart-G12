<div  class="alert alert-<?php echo e($type); ?>">
    <!-- Walk as if you are kissing the Earth with your feet. - Thich Nhat Hanh -->
    <?php echo e($message); ?>

</div>
<?php /**PATH G:\BigStart-G12\E02\resources\views/components/alert.blade.php ENDPATH**/ ?>