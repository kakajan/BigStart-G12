<?php $__env->startSection('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css'); ?>
<?php $__env->startSection('dir', 'ltr'); ?>
<?php $__env->startSection('title'); ?>
    تماس با حاجی
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-6">
                <form action="/messages" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input name="email" type="email" class="form-control" id="email" placeholder="name@example.com">
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone number</label>
                        <input name="mobile" type="tel" class="form-control" id="phone" placeholder="+989112746075">
                    </div>
                    <div class="mb-3">
                        <label for="fullName" class="form-label">Full name</label>
                        <input name="fullName" type="text" class="form-control" id="fullName" placeholder="Full Name">
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Enter your message</label>
                        <textarea name="message" class="form-control" id="message" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <input type="submit" value="Submit" />
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="container " id="messageArea">
        <div class="row justify-content-center">
            <div class="col-6">
                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($message->fullName); ?><br>
                <?php echo e($message->moible); ?><br>
                <?php echo e($message->message); ?>

                <a href="/messages/<?php echo e($message->id); ?>/edit">Edit</a>
                <form method="POST" action="/messages/<?php echo e($message->id); ?>" >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <input type="submit" value="delete">
                </form>
                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\BigStart-G12\E02\resources\views/contact.blade.php ENDPATH**/ ?>