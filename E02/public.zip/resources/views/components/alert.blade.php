<div  class="alert alert-{{ $type }}">
    <!-- Walk as if you are kissing the Earth with your feet. - Thich Nhat Hanh -->
    {{ $message }}
</div>
