@extends('layouts.main')
@section('bootstrap','https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css')
@section('dir', 'ltr')
@section('title')
در باره ما
@endsection
@section('content')
<x-alert type="success" message="salam"/>
سنمیتبنتسی
@endsection
